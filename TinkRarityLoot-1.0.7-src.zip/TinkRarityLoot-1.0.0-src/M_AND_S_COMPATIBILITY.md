# Mine and Slash (M&S) Compatibility Guide

## Overview
TinkRarityLoot (TRL) is now fully compatible with Mine and Slash, allowing TRL items to work seamlessly with M&S affixes, gems, and stat modifications.

## Key Features

### 1. Affix Integration
- **TRL Affixes + M&S Affixes**: TRL-rolled affixes are written to the `mmorpg_gear` JSON tag, making them visible and functional within M&S's system.
- **Socket Support**: Items gain socket slots based on rarity:
  - COMMON / UNCOMMON: 0 sockets
  - RARE: 1 socket
  - EPIC: 2 sockets
  - UNIQUE: 3 sockets
  - LEGENDARY / MYTHIC: 4 sockets

### 2. Stat Bonuses from M&S Affixes
When an M&S affix is applied to a TRL item (via gem insertion or modification), the affix bonuses are automatically converted and applied to TRL's stat system:

**Affix-to-Stat Mapping:**
- Damage prefixes (physical, fire, ice, lightning, poison) → Damage bonus
- Crit prefix → +50% damage bonus equivalent
- Crit damage suffix → Full damage bonus
- Life steal suffix → +50% damage bonus equivalent
- Attack speed suffix → Attack speed delta
- Thorns suffix → Durability bonus (×10)
- Projectile speed suffix → Velocity bonus
- Pierce suffix → Accuracy bonus
- Health suffix → Durability bonus (×5)
- Mana/Energy regen → Durability bonus (×2)
- Experience bonus → Durability bonus (×3)
- Unknown affixes → 50% damage bonus

### 3. Gem Compatibility
- TRL tools can accept M&S gems through sockets (once gems are inserted)
- Gem bonuses are automatically applied to TRL item stats
- Multiple gems can be socketed based on rarity tier

### 4. Potential System
M&S's potential system (which limits modification count) is now integrated:
- COMMON: 3 potential
- UNCOMMON: 4 potential
- RARE: 6 potential
- EPIC: 8 potential
- UNIQUE: 10 potential
- LEGENDARY: 12 potential
- MYTHIC: 15 potential

### 5. Data Persistence
- TRL NBT data is stored in vanilla root tags (`trl_*` keys)
- M&S gear data is stored in `mmorpg_gear` JSON tag
- MnSBridgeFinalizer ensures M&S doesn't overwrite TRL affixes
- If M&S resets the gear data, TRL automatically restores it

## Implementation Details

### Main Compatibility Files

**MnSBridge.java**
- Writes TRL data to `mmorpg_gear` JSON format
- Maps affix types to M&S affix IDs
- Controls socket count and potential based on rarity

**TinkersStatInjector.java**
- Parses M&S affix JSON on items
- Converts affix points to stat bonuses
- Re-patches stats after affix application via `applyMSAffixBonuses()`

**MnSBridgeFinalizer.java**
- Detects when M&S has stripped TRL affixes
- Re-applies TRL affixes and calls bonus application
- Runs on container close and item pickup

### Event Flow

1. **Tool Assembly** (ToolAssemblyHandler):
   - TRL stats are rolled and applied
   - Affixes are generated
   - MnSBridge writes mmorpg_gear JSON

2. **M&S Modification** (Player alters item):
   - M&S updates mmorpg_gear with new affixes
   - MnSBridgeFinalizer detects the change
   - applyMSAffixBonuses() is called
   - New bonuses are integrated into TRL stats
   - ToolStatPatcher re-patches with combined bonuses

3. **Gem Insertion**:
   - M&S inserts gem and updates mmorpg_gear
   - Same process as above
   - Gem bonuses become part of TRL's stat calculation

## Configuration

No additional config needed! The system automatically:
- Detects when M&S is loaded
- Initializes bridging on startup
- Monitors all relevant events

## Compatibility Notes

- **No overwriting**: TRL and M&S data coexist. Neither system overwrites the other.
- **Two-way sync**: Changes in one system are reflected in the other.
- **Fallback support**: If M&S is not loaded, TRL functions normally with all features intact.
- **Tinkers Construct compatibility**: tic_stats are patched by TRL from both sources.

## Future Enhancements

Potential improvements:
- More granular damage type mapping (element types)
- Custom M&S affix definitions specifically for TRL items
- Network sync for multiplayer reliability
- Client-side visualization of combined stat sources

## Troubleshooting

**Stats not updating after gem insertion:**
- Try closing and reopening inventory
- Stats should sync automatically on next tick

**Affixes disappearing:**
- MnSBridgeFinalizer should catch and restore them
- Check logs for [TRL] messages

**Gems not inserting:**
- Ensure item has sockets (check rarity tier)
- M&S may have gear-level restrictions on item types
