package com.tinkrarityloot.client.tooltip;

import com.tinkrarityloot.TinkRarityLoot;
import com.tinkrarityloot.common.capability.ITRLPartStats;
import com.tinkrarityloot.common.event.ToolAssemblyHandler;
import com.tinkrarityloot.common.rarity.TRLRarity;
import com.tinkrarityloot.common.rpg.TRLAffix;
import com.tinkrarityloot.common.rpg.TRLRequirements;
import com.tinkrarityloot.common.stat.WeaponStatBlock;
import com.tinkrarityloot.common.weapon.WeaponFamily;
import com.tinkrarityloot.compat.tinkers.TinkersStatInjector;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import javax.annotation.Nullable;
import java.util.List;

@OnlyIn(Dist.CLIENT)
public final class TooltipRenderer {

    private TooltipRenderer() {}

    private static final Component SEP = Component.literal("\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500")
            .withStyle(ChatFormatting.DARK_GRAY);

    // \u2500\u2500 Part tooltip \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500

    public static void appendPartLines(ItemStack stack, List<Component> lines) {
        WeaponStatBlock stats = getStats(stack);
        if (stats == null) return;

        TRLRarity rarity = stats.rarity;
        int at = Math.min(1, lines.size());

        // Rarity name
        ins(lines, at++, rarity.nameComponent());
        ins(lines, at++, SEP);

        // \u2500\u2500 Durability (all families) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
        ins(lines, at++, lv("Durability",
                String.format("%,d", stats.durability), rarityColour(rarity)));

        // \u2500\u2500 Family-specific stat lines \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
        switch (stats.family) {
            case MELEE_LIGHT, MELEE_HEAVY -> {
                ins(lines, at++, lv("Damage",
                        fmt("+%.2f", stats.damage), rarityColour(rarity)));
                if (Math.abs(stats.attackSpeedDelta) > 0.001f) {
                    ins(lines, at++, lv("Atk Speed",
                            fmt("%+.3f", stats.attackSpeedDelta), atkSpdColour(stats.attackSpeedDelta)));
                }
            }
            case THROWN -> {
                ins(lines, at++, lv("Throw Damage",
                        fmt("+%.2f", stats.damage), rarityColour(rarity)));
                if (stats.velocity > 0.001f)
                    ins(lines, at++, lv("Velocity",
                            fmt("+%.3f", stats.velocity), ChatFormatting.AQUA));
                if (Math.abs(stats.accuracy) > 0.001f)
                    ins(lines, at++, lv("Accuracy",
                            fmt("%+.3f", stats.accuracy), ChatFormatting.GREEN));
            }
            case RANGED -> {
                if (stats.velocity > 0.001f)
                    ins(lines, at++, lv("Velocity",
                            fmt("+%.3f", stats.velocity), ChatFormatting.AQUA));
                if (Math.abs(stats.drawSpeed) > 0.001f)
                    ins(lines, at++, lv("Draw Speed",
                            fmt("%+.3f", stats.drawSpeed), drawSpdColour(stats.drawSpeed)));
                if (Math.abs(stats.accuracy) > 0.001f)
                    ins(lines, at++, lv("Accuracy",
                            fmt("%+.3f", stats.accuracy), ChatFormatting.GREEN));
            }
        }

        // Source level footer
        ins(lines, at++, SEP);
        ins(lines, at, Component.literal("  Source level  ")
                .withStyle(ChatFormatting.DARK_GRAY)
                .append(Component.literal(String.valueOf(stats.mobLevel))
                        .withStyle(ChatFormatting.GRAY)));
    }

    // \u2500\u2500 Assembled tool tooltip \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500

    public static void appendToolLines(ItemStack stack, List<Component> lines,
                                       @Nullable Player player) {
        if (!stack.hasTag()) return;
        if (!stack.getTag().contains(ToolAssemblyHandler.TOOL_RARITY_KEY)) return;

        CompoundTag root = stack.getTag();
        TRLRarity rarity = TRLRarity.fromKey(root.getString(ToolAssemblyHandler.TOOL_RARITY_KEY));

        lines.add(Component.empty());
        lines.add(SEP);

        // \u2500\u2500 Header: Gear Tier + Item Level + Weapon Family \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
        lines.add(Component.literal("  Gear Tier  ")
                .withStyle(ChatFormatting.GRAY)
                .append(rarity.badgeComponent()));

        if (root.contains("trl_mob_level")) {
            lines.add(Component.literal("  Item Level  ")
                    .withStyle(ChatFormatting.GRAY)
                    .append(Component.literal(String.valueOf(root.getInt("trl_mob_level")))
                            .withStyle(ChatFormatting.YELLOW)));
        }

        if (root.contains("trl_weapon_family")) {
            String familyDisplay = familyDisplayName(root.getString("trl_weapon_family"));
            lines.add(Component.literal("  Type  ")
                    .withStyle(ChatFormatting.GRAY)
                    .append(Component.literal(familyDisplay)
                            .withStyle(ChatFormatting.WHITE)));
        } else if (root.contains("trl_tool_family")) {
            String familyDisplay = familyDisplayName(root.getString("trl_tool_family"));
            lines.add(Component.literal("  Type  ")
                    .withStyle(ChatFormatting.GRAY)
                    .append(Component.literal(familyDisplay)
                            .withStyle(ChatFormatting.WHITE)));
        }

        // \u2500\u2500 Requirements (color-coded: green=met, red=not met) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
        if (root.contains(TRLRequirements.K_LEVEL)) {
            int reqLvl  = root.getInt(TRLRequirements.K_LEVEL);
            int reqStr  = root.getInt(TRLRequirements.K_STR);
            int reqDex  = root.getInt(TRLRequirements.K_DEX);
            int reqInt  = root.getInt(TRLRequirements.K_INT);

            int playerLvl = getPlayerLevel(player);

            lines.add(SEP);
            // Color green if met, red if not, gray if player level unknown
            ChatFormatting lvlColour = playerLvl < 0
                    ? ChatFormatting.GRAY
                    : (playerLvl >= reqLvl ? ChatFormatting.GREEN : ChatFormatting.RED);
            lines.add(Component.literal("  Requires  ")
                    .withStyle(ChatFormatting.DARK_GRAY)
                    .append(Component.literal("Level " + reqLvl)
                            .withStyle(lvlColour)));

            if (reqStr > 0 || reqDex > 0 || reqInt > 0) {
                // Read player stats for color-coding (green=met, red=not, gray=unknown)
                int[] pStats = {0, 0, 0};
                boolean statsKnown = false;
                if (player != null && TinkRarityLoot.MINE_AND_SLASH_LOADED) {
                    pStats = com.tinkrarityloot.compat.mineandslash.MnSBridge.getPlayerStats(player);
                    statsKnown = pStats[0] > 0 || pStats[1] > 0 || pStats[2] > 0;
                }

                Component statLine = Component.literal("  ").withStyle(ChatFormatting.DARK_GRAY);
                boolean first = true;
                if (reqStr > 0) {
                    ChatFormatting c = !statsKnown ? ChatFormatting.GRAY
                            : (pStats[0] >= reqStr ? ChatFormatting.GREEN : ChatFormatting.RED);
                    statLine = statLine.copy().append(
                            Component.literal("STR " + reqStr).withStyle(c));
                    first = false;
                }
                if (reqDex > 0) {
                    if (!first) statLine = statLine.copy().append(
                            Component.literal("  ").withStyle(ChatFormatting.DARK_GRAY));
                    ChatFormatting c = !statsKnown ? ChatFormatting.GRAY
                            : (pStats[1] >= reqDex ? ChatFormatting.GREEN : ChatFormatting.RED);
                    statLine = statLine.copy().append(
                            Component.literal("DEX " + reqDex).withStyle(c));
                    first = false;
                }
                if (reqInt > 0) {
                    if (!first) statLine = statLine.copy().append(
                            Component.literal("  ").withStyle(ChatFormatting.DARK_GRAY));
                    ChatFormatting c = !statsKnown ? ChatFormatting.GRAY
                            : (pStats[2] >= reqInt ? ChatFormatting.GREEN : ChatFormatting.RED);
                    statLine = statLine.copy().append(
                            Component.literal("INT " + reqInt).withStyle(c));
                }
                lines.add(statLine);
            }
        }

        // \u2500\u2500 Stat bonuses (Base + Bonus = Final) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
        if (root.getByte(TinkersStatInjector.K_APPLIED) == 1) {
            float bonusDur  = root.getFloat(TinkersStatInjector.K_B_DUR);
            float bonusDmg  = root.getFloat(TinkersStatInjector.K_B_DMG);
            float bonusAspd = root.getFloat(TinkersStatInjector.K_B_ATKSPD);
            float bonusVel  = root.getFloat(TinkersStatInjector.K_B_VEL);
            float bonusDraw = root.getFloat(TinkersStatInjector.K_B_DRAW);
            float bonusAcc  = root.getFloat(TinkersStatInjector.K_B_ACC);

            float baseDur  = root.contains("trl_base_dur")  ? root.getFloat("trl_base_dur")  : 0f;
            float baseDmg  = root.contains("trl_base_dmg")  ? root.getFloat("trl_base_dmg")  : 0f;
            float baseAspd = root.contains("trl_base_aspd") ? root.getFloat("trl_base_aspd") : 0f;
            float baseVel  = root.contains("trl_base_vel")  ? root.getFloat("trl_base_vel")  : 0f;
            float baseDraw = root.contains("trl_base_draw") ? root.getFloat("trl_base_draw") : 0f;
            float baseAcc  = root.contains("trl_base_acc")  ? root.getFloat("trl_base_acc")  : 0f;

            float finalDur  = root.contains("trl_final_dur")  ? root.getFloat("trl_final_dur")  : baseDur + bonusDur;
            float finalDmg  = root.contains("trl_final_dmg")  ? root.getFloat("trl_final_dmg")  : baseDmg + bonusDmg;
            float finalAspd = root.contains("trl_final_aspd") ? root.getFloat("trl_final_aspd") : baseAspd + bonusAspd;
            float finalVel  = root.contains("trl_final_vel")  ? root.getFloat("trl_final_vel")  : baseVel + bonusVel;
            float finalDraw = root.contains("trl_final_draw") ? root.getFloat("trl_final_draw") : baseDraw + bonusDraw;
            float finalAcc  = root.contains("trl_final_acc")  ? root.getFloat("trl_final_acc")  : baseAcc + bonusAcc;

            boolean hasAny = bonusDur > 0 || bonusDmg > 0 || Math.abs(bonusAspd) > 0.001f
                    || bonusVel > 0.001f || Math.abs(bonusDraw) > 0.001f || Math.abs(bonusAcc) > 0.001f;

            if (hasAny) {
                lines.add(SEP);
                lines.add(Component.literal("  TRL Stat Bonuses")
                        .withStyle(ChatFormatting.GOLD));
            }

            ChatFormatting bonusC = ChatFormatting.GREEN;

            if (bonusDur > 0) {
                lines.add(Component.literal("  Durability  ")
                        .withStyle(ChatFormatting.GRAY)
                        .append(Component.literal(String.format("%,d", (int)baseDur))
                                .withStyle(ChatFormatting.WHITE))
                        .append(Component.literal(String.format(" + %,d", (int)bonusDur))
                                .withStyle(bonusC))
                        .append(Component.literal(String.format(" = %,d", (int)finalDur))
                                .withStyle(ChatFormatting.WHITE)));
            }
            if (bonusDmg > 0) {
                lines.add(Component.literal("  Attack Damage  ")
                        .withStyle(ChatFormatting.GRAY)
                        .append(Component.literal(String.format("%.2f", baseDmg))
                                .withStyle(ChatFormatting.WHITE))
                        .append(Component.literal(String.format(" + %.2f", bonusDmg))
                                .withStyle(bonusC))
                        .append(Component.literal(String.format(" = %.2f", finalDmg))
                                .withStyle(ChatFormatting.WHITE)));
            }
            if (Math.abs(bonusAspd) > 0.001f) {
                ChatFormatting spdC = bonusAspd > 0 ? bonusC : ChatFormatting.RED;
                lines.add(Component.literal("  Attack Speed  ")
                        .withStyle(ChatFormatting.GRAY)
                        .append(Component.literal(String.format("%.3f", baseAspd))
                                .withStyle(ChatFormatting.WHITE))
                        .append(Component.literal(String.format(" %+.3f", bonusAspd))
                                .withStyle(spdC))
                        .append(Component.literal(String.format(" = %.3f", finalAspd))
                                .withStyle(ChatFormatting.WHITE)));
            }
            if (bonusVel > 0.001f) {
                lines.add(Component.literal("  Velocity  ")
                        .withStyle(ChatFormatting.GRAY)
                        .append(Component.literal(String.format("%.3f", baseVel))
                                .withStyle(ChatFormatting.WHITE))
                        .append(Component.literal(String.format(" + %.3f", bonusVel))
                                .withStyle(bonusC))
                        .append(Component.literal(String.format(" = %.3f", finalVel))
                                .withStyle(ChatFormatting.WHITE)));
            }
            if (Math.abs(bonusDraw) > 0.001f) {
                // Negative draw = faster = good (green)
                ChatFormatting drawC = bonusDraw < 0 ? bonusC : ChatFormatting.RED;
                lines.add(Component.literal("  Draw Speed  ")
                        .withStyle(ChatFormatting.GRAY)
                        .append(Component.literal(String.format("%.3f", baseDraw))
                                .withStyle(ChatFormatting.WHITE))
                        .append(Component.literal(String.format(" %+.3f", bonusDraw))
                                .withStyle(drawC))
                        .append(Component.literal(String.format(" = %.3f", finalDraw))
                                .withStyle(ChatFormatting.WHITE)));
            }
            if (Math.abs(bonusAcc) > 0.001f) {
                ChatFormatting accC = bonusAcc > 0 ? bonusC : ChatFormatting.RED;
                lines.add(Component.literal("  Accuracy  ")
                        .withStyle(ChatFormatting.GRAY)
                        .append(Component.literal(String.format("%.3f", baseAcc))
                                .withStyle(ChatFormatting.WHITE))
                        .append(Component.literal(String.format(" %+.3f", bonusAcc))
                                .withStyle(accC))
                        .append(Component.literal(String.format(" = %.3f", finalAcc))
                                .withStyle(ChatFormatting.WHITE)));
            }
        }

        // \u2500\u2500 Affixes \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
        if (root.contains(TRLAffix.K_LIST)) {
            ListTag affixList = root.getList(TRLAffix.K_LIST, Tag.TAG_COMPOUND);
            if (!affixList.isEmpty()) {
                lines.add(SEP);
                lines.add(Component.literal("  Affixes")
                        .withStyle(ChatFormatting.LIGHT_PURPLE));
                // Prefixes first
                for (int i = 0; i < affixList.size(); i++) {
                    TRLAffix affix = TRLAffix.fromNbt(affixList.getCompound(i));
                    if (!affix.isPrefix()) continue;
                    String valStr = affix.isPercent()
                            ? String.format("+%.1f%%", affix.value())
                            : String.format("+%.1f", affix.value());
                    lines.add(Component.literal("  \u2726 ")
                            .withStyle(ChatFormatting.AQUA)
                            .append(Component.literal(valStr + " " + affix.displayName()
                                    + " [T" + affix.tier() + "]")
                                    .withStyle(ChatFormatting.AQUA)));
                }
                // Suffixes
                for (int i = 0; i < affixList.size(); i++) {
                    TRLAffix affix = TRLAffix.fromNbt(affixList.getCompound(i));
                    if (affix.isPrefix()) continue;
                    String valStr = affix.isPercent()
                            ? String.format("+%.1f%%", affix.value())
                            : String.format("+%.1f", affix.value());
                    lines.add(Component.literal("  \u25C6 ")
                            .withStyle(ChatFormatting.LIGHT_PURPLE)
                            .append(Component.literal(valStr + " " + affix.displayName()
                                    + " [T" + affix.tier() + "]")
                                    .withStyle(ChatFormatting.LIGHT_PURPLE)));
                }
            }
        }

        // ── Gem Slots ─────────────────────────────────────────────────────────────
        if (root.contains(com.tinkrarityloot.common.rpg.TRLRPGApplicator.K_GEM_SLOTS)) {
            int totalSlots = root.getInt(com.tinkrarityloot.common.rpg.TRLRPGApplicator.K_GEM_SLOTS);
            if (totalSlots > 0) {
                ListTag gemList = root.contains(com.tinkrarityloot.common.rpg.TRLRPGApplicator.K_GEM_LIST)
                        ? root.getList(com.tinkrarityloot.common.rpg.TRLRPGApplicator.K_GEM_LIST, Tag.TAG_COMPOUND)
                        : new ListTag();
                int filledSlots = gemList.size();

                lines.add(SEP);
                lines.add(Component.literal("  Gem Slots  ")
                        .withStyle(ChatFormatting.GREEN)
                        .append(Component.literal(filledSlots + "/" + totalSlots)
                                .withStyle(ChatFormatting.WHITE)));

                // Show filled gems
                for (int i = 0; i < filledSlots; i++) {
                    CompoundTag gemTag = gemList.getCompound(i);
                    String gemName = gemTag.getString("name");
                    if (!gemName.isEmpty()) {
                        lines.add(Component.literal("  \u25C9 ")
                                .withStyle(ChatFormatting.GREEN)
                                .append(Component.literal(gemName)
                                        .withStyle(ChatFormatting.WHITE)));
                    }
                }
                // Show empty slots
                for (int i = filledSlots; i < totalSlots; i++) {
                    lines.add(Component.literal("  \u25CB ")
                            .withStyle(ChatFormatting.DARK_GRAY)
                            .append(Component.literal("Empty Slot")
                                    .withStyle(ChatFormatting.DARK_GRAY)));
                }
            }
        }

        lines.add(SEP);
    }

    // \u2500\u2500 Helpers \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500

    private static int getPlayerLevel(@Nullable Player player) {
        if (player == null) return -1;
        if (TinkRarityLoot.MINE_AND_SLASH_LOADED) {
            int level = com.tinkrarityloot.compat.mineandslash.MnSBridge.getPlayerLevel(player);
            if (level > 0) return level;
            Integer capLevel = com.tinkrarityloot.compat.mineandslash.MineAndSlashCompat.getMobLevel(player);
            if (capLevel != null && capLevel > 0) return capLevel;
        }
        return Math.max(1, player.experienceLevel);
    }

    private static String familyDisplayName(String familyKey) {
        return switch (familyKey.toUpperCase()) {
            case "MELEE_LIGHT" -> "Melee (Light)";
            case "MELEE_HEAVY" -> "Melee (Heavy)";
            case "RANGED"      -> "Ranged";
            case "THROWN"      -> "Thrown";
            default            -> familyKey;
        };
    }

    @Nullable
    public static WeaponStatBlock getStats(ItemStack stack) {
        if (stack.isEmpty()) return null;
        try {
            WeaponStatBlock fromCap = stack.getCapability(ITRLPartStats.CAPABILITY)
                    .filter(c -> c.hasStats() && c.getStats() != null).map(ITRLPartStats::getStats).orElse(null);
            if (fromCap != null) return fromCap;
        } catch (Exception ignored) {}
        if (stack.hasTag() && WeaponStatBlock.isPresent(stack.getTag()))
            return WeaponStatBlock.fromNBT(stack.getTag());
        return null;
    }

    private static Component lv(String label, String value, ChatFormatting valueColour) {
        return Component.literal("  " + label + "  ")
                .withStyle(ChatFormatting.GRAY)
                .append(Component.literal(value).withStyle(valueColour));
    }

    private static String fmt(String pattern, float val) {
        return String.format(pattern, val);
    }

    private static void ins(List<Component> lines, int index, Component c) {
        if (index <= lines.size()) lines.add(index, c);
        else lines.add(c);
    }

    private static ChatFormatting rarityColour(TRLRarity r) {
        return switch (r) {
            case COMMON, UNCOMMON -> ChatFormatting.WHITE;
            case RARE             -> ChatFormatting.AQUA;
            case EPIC             -> ChatFormatting.LIGHT_PURPLE;
            case UNIQUE           -> ChatFormatting.GOLD;
            case LEGENDARY        -> ChatFormatting.YELLOW;
            case MYTHIC           -> ChatFormatting.RED;
        };
    }

    private static ChatFormatting atkSpdColour(float delta) {
        return delta >= 0 ? ChatFormatting.GREEN : ChatFormatting.RED;
    }

    private static ChatFormatting drawSpdColour(float delta) {
        return delta <= 0 ? ChatFormatting.GREEN : ChatFormatting.RED;
    }
}
