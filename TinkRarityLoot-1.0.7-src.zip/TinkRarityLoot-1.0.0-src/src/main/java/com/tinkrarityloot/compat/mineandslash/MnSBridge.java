package com.tinkrarityloot.compat.mineandslash;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.tinkrarityloot.TinkRarityLoot;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.lang.reflect.Method;

/**
 * Mine and Slash Compatibility Layer (Read-Only Integration)
 *
 * ── Architecture ──────────────────────────────────────────────────────────────
 * TRL is the SOURCE OF TRUTH. This bridge ONLY detects and reads M&S data,
 * it does NOT convert TRL data to M&S format.
 *
 * ── Player data access ────────────────────────────────────────────────────────
 * M&S 6.x (robertx22) stores player level and stats in its own capability
 * system accessed via:
 *   com.robertx22.mine_and_slash.uncommon.datasaving.Load.Unit(LivingEntity) → UnitData
 *   UnitData.getLevel()
 *   UnitData.getUnit() → Unit
 *
 * We access all M&S internals via reflection so TRL compiles and runs without
 * M&S on the classpath.
 */
public final class MnSBridge {

    private static boolean masLoaded = false;

    // ── Reflected M&S API handles ─────────────────────────────────────────────
    // Load.Unit(LivingEntity) → UnitData
    private static Method loadUnitMethod = null;
    // UnitData.getLevel()
    private static Method getLevelMethod = null;
    // UnitData.getUnit() → Unit (for stat access)
    private static Method getUnitMethod = null;

    // Fallback: getPersistentData()-based approach (works if M&S populates ForgeData)
    private static boolean reflectionAvailable = false;

    private static boolean initLogged = false;

    private MnSBridge() {}

    public static void init() {
        // Detect M&S on classpath — try multiple known package roots
        String[] refClasses = {
            "com.robertx22.mine_and_slash.mmorpg.Ref",
            "com.robertx22.age_of_exile.mmorpg.Ref",
            "com.verdantartifice.mineandslash.MineAndSlash"
        };
        for (String cls : refClasses) {
            try {
                Class.forName(cls);
                masLoaded = true;
                TinkRarityLoot.LOGGER.info("[TRL] MnSBridge: M&S detected via {}", cls);
                break;
            } catch (ClassNotFoundException ignored) {}
        }
        // Also check via Forge mod list as fallback
        if (!masLoaded && TinkRarityLoot.MINE_AND_SLASH_LOADED) {
            masLoaded = true;
            TinkRarityLoot.LOGGER.info("[TRL] MnSBridge: M&S detected via mod list (modid mmorpg)");
        }
        if (!masLoaded) {
            TinkRarityLoot.LOGGER.debug("[TRL] MnSBridge: M&S not found");
            return;
        }

        // Try to reflect into M&S data access API
        initReflection();
    }

    /**
     * Reflect into M&S's data loading API. Tries multiple known class paths
     * across different M&S 6.x versions.
     */
    private static void initReflection() {
        // Try known Load class locations
        String[] loadClassPaths = {
            "com.robertx22.mine_and_slash.uncommon.datasaving.Load",
            "com.robertx22.mine_and_slash.saveclasses.loading.Load",
            "com.robertx22.mine_and_slash.database.data.load.Load",
            "com.robertx22.mine_and_slash.api.Load",
            "com.robertx22.age_of_exile.uncommon.datasaving.Load",
            "com.robertx22.age_of_exile.database.data.load.Load",
            "com.verdantartifice.mineandslash.uncommon.datasaving.Load",
            "com.verdantartifice.mineandslash.common.datasaving.Load",
            "com.verdantartifice.mineandslash.api.Load"
        };

        Class<?> loadClass = null;
        for (String path : loadClassPaths) {
            try {
                loadClass = Class.forName(path);
                TinkRarityLoot.LOGGER.info("[TRL] MnSBridge: Found Load class at {}", path);
                break;
            } catch (ClassNotFoundException ignored) {}
        }

        if (loadClass == null) {
            TinkRarityLoot.LOGGER.warn("[TRL] MnSBridge: Could not find M&S Load class. "
                    + "Falling back to getPersistentData() for player level/stats.");
            return;
        }

        // Find Load.Unit(LivingEntity) method
        try {
            // Try different method signatures
            for (String methodName : new String[]{"Unit", "unit", "getUnitData"}) {
                try {
                    loadUnitMethod = loadClass.getMethod(methodName, LivingEntity.class);
                    break;
                } catch (NoSuchMethodException ignored) {}
            }

            if (loadUnitMethod == null) {
                TinkRarityLoot.LOGGER.warn("[TRL] MnSBridge: Load class found but no Unit() method. "
                        + "Available methods: {}", java.util.Arrays.toString(loadClass.getDeclaredMethods()));
                return;
            }

            // Get the return type (UnitData) and find getLevel()
            Class<?> unitDataClass = loadUnitMethod.getReturnType();
            TinkRarityLoot.LOGGER.info("[TRL] MnSBridge: UnitData class = {}", unitDataClass.getName());

            for (String name : new String[]{"getLevel", "level"}) {
                try {
                    getLevelMethod = unitDataClass.getMethod(name);
                    break;
                } catch (NoSuchMethodException ignored) {}
            }

            // Try to find getUnit() for deeper stat access
            for (String name : new String[]{"getUnit", "unit", "getStats"}) {
                try {
                    getUnitMethod = unitDataClass.getMethod(name);
                    break;
                } catch (NoSuchMethodException ignored) {}
            }

            if (getLevelMethod != null) {
                reflectionAvailable = true;
                TinkRarityLoot.LOGGER.info("[TRL] MnSBridge: Reflection API ready "
                        + "(getLevel={}, getUnit={})",
                        getLevelMethod.getName(),
                        getUnitMethod != null ? getUnitMethod.getName() : "N/A");
            } else {
                TinkRarityLoot.LOGGER.warn("[TRL] MnSBridge: UnitData class found but no getLevel(). "
                        + "Methods: {}", java.util.Arrays.toString(unitDataClass.getDeclaredMethods()));
            }

        } catch (Exception e) {
            TinkRarityLoot.LOGGER.warn("[TRL] MnSBridge: Reflection init failed: {}", e.getMessage());
        }
    }

    /**
     * Check if an item has M&S gear data.
     */
    public static boolean hasMasData(ItemStack stack) {
        if (stack.isEmpty() || !stack.hasTag()) return false;
        return stack.getTag().contains("mmorpg_gear");
    }

    public static boolean wasMasStripped(ItemStack stack) {
        return false;
    }

    // ── Player level ─────────────────────────────────────────────────────────

    /**
     * Read M&S player level. Returns -1 if unavailable.
     *
     * Tries reflection API first (Load.Unit(player).getLevel()),
     * then falls back to getPersistentData() check.
     */
    public static int getPlayerLevel(Player player) {
        if (!masLoaded) return -1;

        // Primary: reflection into M&S API
        if (reflectionAvailable) {
            try {
                Object unitData = loadUnitMethod.invoke(null, player);
                if (unitData != null) {
                    Object result = getLevelMethod.invoke(unitData);
                    if (result instanceof Number n) {
                        int level = n.intValue();
                        if (level > 0) return level;
                    }
                }
            } catch (Exception e) {
                if (!initLogged) {
                    TinkRarityLoot.LOGGER.debug("[TRL] MnSBridge: Reflection getLevel failed: {}", e.getMessage());
                }
            }
        }

        // Fallback: getPersistentData() (some M&S versions sync data here)
        try {
            CompoundTag forgeCaps = player.getPersistentData();
            // Try multiple known key paths
            for (String entityKey : new String[]{
                    "mmorpg:entity_data", "mmorpg_entity_data", "mmorpg:player_data"}) {
                if (forgeCaps.contains(entityKey)) {
                    CompoundTag entityData = forgeCaps.getCompound(entityKey);
                    for (String lvlKey : new String[]{"level", "lvl", "player_level"}) {
                        if (entityData.contains(lvlKey)) {
                            int level = entityData.getInt(lvlKey);
                            if (level > 0) return level;
                        }
                    }
                }
            }
            // Also check direct keys on forgeData
            if (forgeCaps.contains("level")) {
                int level = forgeCaps.getInt("level");
                if (level > 0) return level;
            }
        } catch (Exception e) {
            TinkRarityLoot.LOGGER.debug("[TRL] MnSBridge: Fallback level read failed: {}", e.getMessage());
        }

        // Debug: log what data IS available (once)
        if (!initLogged) {
            initLogged = true;
            try {
                CompoundTag data = player.getPersistentData();
                if (!data.getAllKeys().isEmpty()) {
                    TinkRarityLoot.LOGGER.warn("[TRL] MnSBridge: Cannot read player level. "
                            + "getPersistentData keys: {} — "
                            + "If M&S is installed, report these keys to TRL developers.",
                            data.getAllKeys());
                } else {
                    TinkRarityLoot.LOGGER.warn("[TRL] MnSBridge: getPersistentData is empty. "
                            + "M&S likely stores data via capabilities only.");
                }
            } catch (Exception ignored) {}
        }

        return -1;
    }

    // ── Player stats (STR, DEX, INT) ─────────────────────────────────────────

    /**
     * Read M&S player stat allocations.
     * Returns int[3] = {str, dex, int}. All zeros if unavailable.
     *
     * M&S stat access is version-dependent. We try:
     * 1. Reflection: UnitData → Unit → stat lookups
     * 2. Fallback: getPersistentData() with multiple key patterns
     */
    private static boolean statWarningLogged = false;

    public static int[] getPlayerStats(Player player) {
        int[] stats = {0, 0, 0};
        if (!masLoaded) return stats;

        // Primary: reflection API
        if (reflectionAvailable && getUnitMethod != null) {
            try {
                Object unitData = loadUnitMethod.invoke(null, player);
                if (unitData != null) {
                    Object unit = getUnitMethod.invoke(unitData);
                    if (unit != null) {
                        stats[0] = readStatReflection(unit, "str", "strength", "Strength");
                        stats[1] = readStatReflection(unit, "dex", "dexterity", "Dexterity");
                        stats[2] = readStatReflection(unit, "int", "intelligence", "Intelligence");
                        if (stats[0] > 0 || stats[1] > 0 || stats[2] > 0) return stats;
                    }
                }
            } catch (Exception e) {
                TinkRarityLoot.LOGGER.debug("[TRL] MnSBridge: Reflection stat read failed: {}", e.getMessage());
            }
        }

        // Fallback: getPersistentData()
        try {
            CompoundTag forgeCaps = player.getPersistentData();
            for (String entityKey : new String[]{
                    "mmorpg:entity_data", "mmorpg_entity_data", "mmorpg:player_data"}) {
                if (!forgeCaps.contains(entityKey)) continue;
                CompoundTag entityData = forgeCaps.getCompound(entityKey);

                // Try nested compound keys
                for (String statKey : new String[]{
                        "stat_soul", "stat_points", "stats", "stat_data",
                        "stat_alloc", "allocated_stats", "core_stats", "player_stats"}) {
                    if (entityData.contains(statKey, 10 /* CompoundTag */)) {
                        CompoundTag statData = entityData.getCompound(statKey);
                        stats[0] = readStatNbt(statData, "str", "strength");
                        stats[1] = readStatNbt(statData, "dex", "dexterity");
                        stats[2] = readStatNbt(statData, "int", "intelligence");
                        if (stats[0] > 0 || stats[1] > 0 || stats[2] > 0) return stats;
                    }
                }

                // Try flat keys directly on entityData
                stats[0] = readStatNbt(entityData, "str", "strength");
                stats[1] = readStatNbt(entityData, "dex", "dexterity");
                stats[2] = readStatNbt(entityData, "int", "intelligence");
                if (stats[0] > 0 || stats[1] > 0 || stats[2] > 0) return stats;
            }
        } catch (Exception e) {
            TinkRarityLoot.LOGGER.debug("[TRL] MnSBridge: Fallback stat read failed: {}", e.getMessage());
        }

        // Log warning once
        if (!statWarningLogged) {
            statWarningLogged = true;
            TinkRarityLoot.LOGGER.warn("[TRL] MnSBridge: Cannot read player stats (STR/DEX/INT). "
                    + "Stat requirements will not be enforced until M&S stat reading is resolved.");
        }

        return stats;
    }

    /**
     * Try to read a stat value via reflection on the Unit object.
     * M&S Unit objects may have getStat(String), getStatValue(String), or
     * direct field access.
     */
    private static int readStatReflection(Object unit, String... names) {
        Class<?> clazz = unit.getClass();

        // Try getStat(String) or getStatLevel(String) methods with each name
        for (String methodName : new String[]{"getStat", "getStatLevel", "getStatValue"}) {
            try {
                Method m = clazz.getMethod(methodName, String.class);
                for (String name : names) {
                    try {
                        Object result = m.invoke(unit, name);
                        if (result instanceof Number n) {
                            int val = n.intValue();
                            if (val > 0) return val;
                        }
                    } catch (Exception ignored) {}
                }
            } catch (NoSuchMethodException ignored) {}
        }

        // Try direct getter methods
        for (String name : names) {
            String getter = "get" + name.substring(0, 1).toUpperCase() + name.substring(1);
            try {
                Method m = clazz.getMethod(getter);
                Object result = m.invoke(unit);
                if (result instanceof Number n) return n.intValue();
            } catch (Exception ignored) {}
        }

        return 0;
    }

    /** Read a stat value from NBT trying both short and long key names. */
    private static int readStatNbt(CompoundTag data, String shortKey, String longKey) {
        if (data.contains(shortKey)) return data.getInt(shortKey);
        if (data.contains(longKey)) return data.getInt(longKey);
        return 0;
    }

    // ── Item data ─────────────────────────────────────────────────────────────

    /**
     * Extract M&S affix data from mmorpg_gear JSON.
     */
    public static String extractMasAffixData(ItemStack stack) {
        if (!hasMasData(stack)) return "";
        try {
            String json = stack.getTag().getString("mmorpg_gear");
            JsonObject gear = JsonParser.parseString(json).getAsJsonObject();
            if (gear.has("affixes")) {
                return gear.getAsJsonObject("affixes").toString();
            }
        } catch (Exception e) {
            TinkRarityLoot.LOGGER.debug("[TRL] Failed to parse M&S affix data: {}", e.getMessage());
        }
        return "";
    }

    /**
     * Check if M&S is loaded in this instance.
     */
    public static boolean isMasLoaded() {
        return masLoaded;
    }
}
