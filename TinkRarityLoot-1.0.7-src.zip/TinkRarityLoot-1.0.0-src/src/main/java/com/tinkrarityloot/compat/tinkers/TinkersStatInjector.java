package com.tinkrarityloot.compat.tinkers;

import com.tinkrarityloot.TinkRarityLoot;
import com.tinkrarityloot.common.config.TRLConfig;
import com.tinkrarityloot.common.event.ToolAssemblyHandler;
import com.tinkrarityloot.common.stat.WeaponStatBlock;
import com.tinkrarityloot.common.weapon.WeaponFamily;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/**
 * Stores TRL stat bonuses in vanilla NBT and triggers the initial patch.
 *
 * ── Architecture ──────────────────────────────────────────────────────────
 *
 * Single path: ToolStatPatcher is the sole authority for writing tic_stats.
 * This class only:
 *   1. Sums bonuses from part stat blocks
 *   2. Writes them to vanilla root NBT (trl_b_* keys) for persistence
 *   3. Calls ToolStatPatcher.patch() once for the initial application
 *
 * TRLRarityModifier is kept only for the tooltip badge — it does NOT inject
 * stats (its addToolStats hook is empty). The modifier path was abandoned
 * because TCon 3.11 rebuilds tic_modifiers from tic_materials on every
 * rebuildStats() call, wiping any injected entries.
 *
 * ── Storage keys (vanilla root tag) ──────────────────────────────────────
 *
 *   trl_applied   byte 1  — set once at assembly; guards against re-application
 *   trl_b_dur     float   — durability bonus
 *   trl_b_dmg     float   — damage bonus
 *   trl_b_atkspd  float   — attack speed delta
 *   trl_b_vel     float   — velocity bonus (ranged/thrown)
 *   trl_b_draw    float   — draw speed delta (ranged)
 *   trl_b_acc     float   — accuracy delta (ranged/thrown)
 */
public final class TinkersStatInjector {

    public static final String K_APPLIED  = "trl_applied";
    public static final String K_B_DUR    = "trl_b_dur";
    public static final String K_B_DMG    = "trl_b_dmg";
    public static final String K_B_ATKSPD = "trl_b_atkspd";
    public static final String K_B_VEL    = "trl_b_vel";
    public static final String K_B_DRAW   = "trl_b_draw";
    public static final String K_B_ACC    = "trl_b_acc";

    // Component-only bonuses (sum of rolled part stats, stored at first assembly)
    public static final String K_CB_DUR    = "trl_cb_dur";
    public static final String K_CB_DMG    = "trl_cb_dmg";
    public static final String K_CB_ATKSPD = "trl_cb_atkspd";
    public static final String K_CB_VEL    = "trl_cb_vel";
    public static final String K_CB_DRAW   = "trl_cb_draw";
    public static final String K_CB_ACC    = "trl_cb_acc";

    private static final float MAX_ATK_SPD =  0.18f;
    private static final float MIN_ATK_SPD = -0.20f;

    private TinkersStatInjector() {}

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    private static int rarityOrdinal(String key) {
        return switch (key) {
            case "uncommon"  -> 1;
            case "rare"      -> 2;
            case "epic"      -> 3;
            case "unique"    -> 4;
            case "legendary" -> 5;
            case "mythic"    -> 6;
            default          -> 0;
        };
    }

    /**
     * Called at tool assembly. Stores component stat bonuses and applies TRL + M&S affix bonuses.
     *
     * Component stats (durability, damage, etc.) from TRL parts are summed and stored
     * as the base bonus (trl_cb_* keys). TRL affix bonuses are computed on top via
     * rebuildTotalBonuses(). The combined total is stored in trl_b_* keys, which are
     * ADDITIONS to Tinkers' material-based stats in tic_stats.
     */
    public static void applyBonuses(ItemStack toolStack, List<WeaponStatBlock> partStats) {
        if (!TRLConfig.SERVER.enableTinkersStatInjection.get()) return;
        if (partStats.isEmpty()) return;

        CompoundTag root = toolStack.getOrCreateTag();
        if (root.getByte(K_APPLIED) == 1) {
            // Already applied (repair/modify path) — rebuild total bonuses
            // and clear fingerprint so patch() re-applies with fresh base values.
            rebuildTotalBonuses(toolStack);
            root.remove("trl_stat_fp");
            com.tinkrarityloot.common.event.ToolStatPatcher.patch(toolStack, true);
            applyMSAffixBonuses(toolStack);
            return;
        }

        // === First-time assembly ===
        root.putByte(K_APPLIED, (byte) 1);

        // Sum component stats from all TRL parts
        float totalDur = 0f, totalDmg = 0f, bestAspd = 0f;
        float totalVel = 0f, bestDraw = 0f, totalAcc = 0f;
        for (WeaponStatBlock block : partStats) {
            totalDur += block.durability;
            totalDmg += block.damage;
            if (Math.abs(block.attackSpeedDelta) > Math.abs(bestAspd))
                bestAspd = block.attackSpeedDelta;
            totalVel += block.velocity;
            if (Math.abs(block.drawSpeed) > Math.abs(bestDraw))
                bestDraw = block.drawSpeed;
            totalAcc += block.accuracy;
        }
        bestAspd = clamp(bestAspd, MIN_ATK_SPD, MAX_ATK_SPD);

        // Persist component-only bonuses (immutable after assembly)
        root.putFloat(K_CB_DUR, totalDur);
        root.putFloat(K_CB_DMG, totalDmg);
        root.putFloat(K_CB_ATKSPD, bestAspd);
        root.putFloat(K_CB_VEL, totalVel);
        root.putFloat(K_CB_DRAW, bestDraw);
        root.putFloat(K_CB_ACC, totalAcc);

        // Store rarity index for tooltip badge
        if (root.contains(ToolAssemblyHandler.TOOL_RARITY_KEY)) {
            root.putInt("trl_rarity_idx", rarityOrdinal(
                    root.getString(ToolAssemblyHandler.TOOL_RARITY_KEY)));
        }

        // Build total bonuses = component + affix (idempotent)
        rebuildTotalBonuses(toolStack);

        // Initial patch — ToolStatPatcher writes bonuses into tic_stats
        com.tinkrarityloot.common.event.ToolStatPatcher.patch(toolStack, true);

        // Apply M&S affix bonuses (from gems, if present)
        applyMSAffixBonuses(toolStack);

        TinkRarityLoot.LOGGER.info(
                "[TRL] applyBonuses: component bonuses dur={} dmg={} aspd={}",
                (int) totalDur, String.format("%.2f", totalDmg),
                String.format("%.3f", bestAspd));
    }

    /**
     * Idempotent rebuild of total bonuses (trl_b_*) from component sums (trl_cb_*)
     * plus TRL affix tool-stat bonuses. Always starts from component base values,
     * so calling multiple times produces the same result.
     */
    private static void rebuildTotalBonuses(ItemStack toolStack) {
        CompoundTag root = toolStack.getTag();
        if (root == null) return;

        // Start from component base
        float dur    = root.getFloat(K_CB_DUR);
        float dmg    = root.getFloat(K_CB_DMG);
        float atkspd = root.getFloat(K_CB_ATKSPD);
        float vel    = root.getFloat(K_CB_VEL);
        float draw   = root.getFloat(K_CB_DRAW);
        float acc    = root.getFloat(K_CB_ACC);

        // Add TRL affix tool-stat bonuses
        if (root.contains(com.tinkrarityloot.common.rpg.TRLAffix.K_LIST)) {
            net.minecraft.nbt.ListTag affixList = root.getList(
                    com.tinkrarityloot.common.rpg.TRLAffix.K_LIST,
                    net.minecraft.nbt.Tag.TAG_COMPOUND);
            float[] ab = {0f, 0f, 0f, 0f, 0f, 0f};
            for (int i = 0; i < affixList.size(); i++) {
                com.tinkrarityloot.common.rpg.TRLAffix affix =
                        com.tinkrarityloot.common.rpg.TRLAffix.fromNbt(
                                affixList.getCompound(i));
                applyToolAffixBonus(affix.type(), affix.value(), ab);
            }
            dur    += ab[0];
            dmg    += ab[1];
            atkspd  = clamp(atkspd + ab[2], MIN_ATK_SPD, MAX_ATK_SPD);
            vel    += ab[3];
            draw   += ab[4];
            acc    += ab[5];
        }

        // Store total bonuses (component + affix)
        root.putFloat(K_B_DUR, dur);
        root.putFloat(K_B_DMG, dmg);
        root.putFloat(K_B_ATKSPD, atkspd);
        root.putFloat(K_B_VEL, vel);
        root.putFloat(K_B_DRAW, draw);
        root.putFloat(K_B_ACC, acc);
    }

    /**
     * Map a TRL affix type to tool stat bonuses (indices: 0=dur, 1=dmg, 2=atkspd, 3=vel, 4=draw, 5=acc).
     * Player-affecting affixes (MAX_HP_PCT, LIFE_STEAL, etc.) are NOT mapped here —
     * they are handled via Minecraft AttributeModifiers in ToolStatPatcher.
     */
    private static void applyToolAffixBonus(String type, float value, float[] b) {
        switch (type) {
            case com.tinkrarityloot.common.rpg.TRLAffix.PHYS_DMG_PCT  -> b[1] += value * 0.1f;
            case com.tinkrarityloot.common.rpg.TRLAffix.FIRE_DMG      -> b[1] += value * 0.1f;
            case com.tinkrarityloot.common.rpg.TRLAffix.ICE_DMG       -> b[1] += value * 0.1f;
            case com.tinkrarityloot.common.rpg.TRLAffix.LIGHTNING_DMG -> b[1] += value * 0.1f;
            case com.tinkrarityloot.common.rpg.TRLAffix.POISON_DMG    -> b[1] += value * 0.1f;
            case com.tinkrarityloot.common.rpg.TRLAffix.CRIT_CHANCE   -> b[1] += value * 0.05f;
            case com.tinkrarityloot.common.rpg.TRLAffix.CRIT_DMG      -> b[1] += value * 0.1f;
            case com.tinkrarityloot.common.rpg.TRLAffix.ATK_SPEED_PCT -> b[2] += value * 0.001f;
            case com.tinkrarityloot.common.rpg.TRLAffix.THORNS        -> b[0] += value * 5f;
            case com.tinkrarityloot.common.rpg.TRLAffix.PROJ_SPEED    -> b[3] += value * 0.01f;
            case com.tinkrarityloot.common.rpg.TRLAffix.PIERCE_CHANCE -> b[5] += value * 0.01f;
            // Player-affecting: MAX_HP_PCT, LIFE_STEAL, MANA_REGEN, ENERGY_REGEN, EXP_BONUS
            // → handled via Minecraft AttributeModifiers, not tool stat bonuses
        }
    }

    /**
     * Apply M&S affix bonuses to the tool's stats in addition to TRL bonuses.
     * This ensures M&S affixes function on TRL items.
     */
    public static void applyMSAffixBonuses(ItemStack toolStack) {
        if (!TinkRarityLoot.MINE_AND_SLASH_LOADED) return;
        if (toolStack.isEmpty() || !toolStack.hasTag()) return;

        CompoundTag root = toolStack.getTag();
        if (!root.contains("mmorpg_gear")) return;

        String masJson = root.getString("mmorpg_gear");
        try {
            JsonObject gear = JsonParser.parseString(masJson).getAsJsonObject();
            if (!gear.has("affixes")) return;

            JsonObject affixes = gear.getAsJsonObject("affixes");
            float[] bonuses = new float[6]; // dur, dmg, atkspd, vel, draw, acc

            // Parse prefixes
            if (affixes.has("pre")) {
                JsonArray pre = affixes.getAsJsonArray("pre");
                for (JsonElement elem : pre) {
                    JsonObject affix = elem.getAsJsonObject();
                    String id = affix.get("id").getAsString();
                    int points = affix.get("p").getAsInt();
                    applyAffixBonus(id, points, bonuses);
                }
            }

            // Parse suffixes
            if (affixes.has("suf")) {
                JsonArray suf = affixes.getAsJsonArray("suf");
                for (JsonElement elem : suf) {
                    JsonObject affix = elem.getAsJsonObject();
                    String id = affix.get("id").getAsString();
                    int points = affix.get("p").getAsInt();
                    applyAffixBonus(id, points, bonuses);
                }
            }

            // Apply the bonuses if any
            if (bonuses[0] != 0 || bonuses[1] != 0 || bonuses[2] != 0 || bonuses[3] != 0 || bonuses[4] != 0 || bonuses[5] != 0) {
                root.putFloat(K_B_DUR, root.getFloat(K_B_DUR) + bonuses[0]);
                root.putFloat(K_B_DMG, root.getFloat(K_B_DMG) + bonuses[1]);
                root.putFloat(K_B_ATKSPD, root.getFloat(K_B_ATKSPD) + bonuses[2]);
                root.putFloat(K_B_VEL, root.getFloat(K_B_VEL) + bonuses[3]);
                root.putFloat(K_B_DRAW, root.getFloat(K_B_DRAW) + bonuses[4]);
                root.putFloat(K_B_ACC, root.getFloat(K_B_ACC) + bonuses[5]);

                // Re-patch to apply the new bonuses
                com.tinkrarityloot.common.event.ToolStatPatcher.patch(toolStack, true);

                TinkRarityLoot.LOGGER.debug("[TRL] Applied M&S affix bonuses: dur+{} dmg+{} spd+{}",
                        bonuses[0], bonuses[1], bonuses[2]);
            }
        } catch (Exception e) {
            TinkRarityLoot.LOGGER.debug("[TRL] Failed to parse M&S affixes: {}", e.getMessage());
        }
    }

    private static void applyAffixBonus(String id, int points, float[] bonuses) {
        // Convert M&S affix points to stat bonuses
        // This is approximate - adjust based on M&S balance
        float value = points / 10f; // M&S points are stored *10

        switch (id) {
            case "physical_prefix" -> bonuses[1] += value;
            case "fire_prefix" -> bonuses[1] += value; // Could differentiate damage types if needed
            case "ice_prefix" -> bonuses[1] += value;
            case "lightning_prefix" -> bonuses[1] += value;
            case "poison_prefix" -> bonuses[1] += value;
            case "crit_prefix" -> bonuses[1] += value * 0.5f; // Crit as damage bonus
            case "crit_dmg_suffix" -> bonuses[1] += value;
            case "life_steal_suffix" -> bonuses[1] += value * 0.5f;
            case "attack_speed_suffix" -> bonuses[2] += value;
            case "thorns_suffix" -> bonuses[0] += value * 10f; // Thorns as durability
            case "projectile_speed_suffix" -> bonuses[3] += value;
            case "pierce_suffix" -> bonuses[5] += value;
            case "health_suffix" -> bonuses[0] += value * 5f; // Health as durability
            case "mana_regen_suffix" -> bonuses[0] += value * 2f;
            case "energy_regen_suffix" -> bonuses[0] += value * 2f;
            case "exp_suffix" -> bonuses[0] += value * 3f;
            default -> bonuses[1] += value * 0.5f; // Default damage bonus
        }
    }
}
