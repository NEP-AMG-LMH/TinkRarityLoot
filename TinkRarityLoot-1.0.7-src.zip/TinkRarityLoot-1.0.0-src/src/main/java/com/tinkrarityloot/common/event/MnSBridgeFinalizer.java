package com.tinkrarityloot.common.event;

import com.tinkrarityloot.TinkRarityLoot;
import com.tinkrarityloot.common.rpg.TRLAffix;
import com.tinkrarityloot.common.rpg.TRLRPGApplicator;
import com.tinkrarityloot.compat.mineandslash.MnSBridge;
import com.tinkrarityloot.compat.tinkers.TinkersStatInjector;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerContainerEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Applies M&S Affix Bonuses to TRL Tools
 *
 * ── New Architecture ──────────────────────────────────────────────────────────
 * This class now only handles the OPTIONAL M&S integration:
 *
 * If a user applies M&S modifications to a TRL tool:
 * 1. M&S writes to mmorpg_gear JSON tag
 * 2. This finalizer detects the presence of M&S data
 * 3. Calls TinkersStatInjector.applyMSAffixBonuses() to apply M&S affix bonuses
 * 4. TRL data remains unchanged — no data recovery or overwrite logic needed
 *
 * ── TRL data integrity ────────────────────────────────────────────────────────
 * We no longer convert TRL data to M&S format, so there's nothing for
 * M&S to overwrite. TRL is always the source of truth.
 *
 * M&S modifications (gems, affixes) are optional enhancements that apply
 * bonuses directly to the TRL stat system via TinkersStatInjector.
 */
public class MnSBridgeFinalizer {

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onContainerClose(PlayerContainerEvent.Close event) {
        Player player = event.getEntity();
        if (player.level().isClientSide()) return;
        scanAndApplyBonuses(player);
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onItemPickup(PlayerEvent.ItemPickupEvent event) {
        if (event.getEntity().level().isClientSide()) return;
        applyMSBonusesIfNeeded(event.getStack());
    }

    /** Scan entire inventory for TRL tools with M&S data and apply bonuses. */
    public static void scanAndApplyBonuses(Player player) {
        if (!MnSBridge.isMasLoaded()) return;
        int updated = 0;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            if (applyMSBonusesIfNeeded(player.getInventory().getItem(i))) updated++;
        }
        if (updated > 0)
            TinkRarityLoot.LOGGER.debug("[TRL] MnSBridgeFinalizer: applied M&S bonuses to {} tool(s)", updated);
    }

    /**
     * Check if an item has M&S data and apply affix bonuses.
     * Returns true if bonuses were applied.
     */
    public static boolean applyMSBonusesIfNeeded(ItemStack stack) {
        if (stack.isEmpty() || !stack.hasTag()) return false;
        if (!MnSBridge.isMasLoaded()) return false;
        CompoundTag root = stack.getTag();

        // Only process TRL-assembled tools
        if (root.getByte(TRLRPGApplicator.K_RPG_APPLIED) != 1) return false;

        // Check if this item has M&S data
        if (!MnSBridge.hasMasData(stack)) return false;

        // Apply M&S affix bonuses to TRL stats
        TinkersStatInjector.applyMSAffixBonuses(stack);
        TinkRarityLoot.LOGGER.debug("[TRL] MnSBridgeFinalizer: applied M&S affix bonuses");
        return true;
    }
}
