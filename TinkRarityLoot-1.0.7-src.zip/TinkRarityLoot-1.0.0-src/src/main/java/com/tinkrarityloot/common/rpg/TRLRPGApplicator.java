package com.tinkrarityloot.common.rpg;

import com.tinkrarityloot.TinkRarityLoot;
import com.tinkrarityloot.common.event.ToolAssemblyHandler;
import com.tinkrarityloot.common.rarity.TRLRarity;
import com.tinkrarityloot.common.weapon.WeaponFamily;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.item.ItemStack;

import java.util.List;
import java.util.Random;

/**
 * Entry point: roll and apply all RPG data to an assembled TRL tool.
 *
 * Called from ToolAssemblyHandler after a tool is crafted from TRL parts.
 * The mob level comes from the lootbox NBT (trl_mob_level on the dominant part).
 *
 * ── Architecture ──────────────────────────────────────────────────────────────
 * TRL is the SOURCE OF TRUTH. We write all data to vanilla TRL NBT keys.
 * Mine and Slash integration is OPTIONAL and read-only:
 * - If M&S is loaded, TRL tools can accept M&S affixes/gems
 * - M&S affixes are parsed and applied as TRL stat bonuses
 * - TRL data is never converted to M&S format (avoids M&S overwriting it)
 *
 * ── What happens ─────────────────────────────────────────────────────────────
 *   1. Roll requirements (level gate + stat requirements)
 *   2. Roll affixes (prefix/suffix pool, count by rarity)
 *   3. Write all data to TRL NBT keys (this is it!)
 *   4. Mark trl_rpg_applied = 1 so this never runs twice
 *   5. (Optional) If M&S is loaded, detect it and apply M&S affix bonuses
 */
public final class TRLRPGApplicator {

    public static final String K_RPG_APPLIED = "trl_rpg_applied";
    public static final String K_GEM_SLOTS  = "trl_gem_slots";
    public static final String K_GEM_LIST   = "trl_gems";

    private TRLRPGApplicator() {}

    public static void apply(ItemStack tool, TRLRarity rarity,
                              WeaponFamily family, int mobLevel, Random random) {
        if (tool.isEmpty()) return;
        if (tool.hasTag() && tool.getTag().getByte(K_RPG_APPLIED) == 1) return;

        // 1. Roll requirements
        TRLRequirements reqs = TRLRequirementsRoller.roll(mobLevel, rarity, family);

        // 2. Roll affixes
        List<TRLAffix> affixes = TRLAffixRoller.roll(rarity, family, mobLevel, random);

        // 3. Write directly to TRL NBT (source of truth)
        CompoundTag root = tool.getOrCreateTag();
        
        // Write requirements
        reqs.writeToTag(root);
        
        // Write affixes list
        ListTag affixList = new ListTag();
        for (TRLAffix affix : affixes) {
            affixList.add(affix.toNbt());
        }
        root.put(TRLAffix.K_LIST, affixList);
        
        // Store rarity and family for later retrieval
        root.putString(ToolAssemblyHandler.TOOL_RARITY_KEY, rarity.getSerialKey());
        storeFamily(root, family);

        // 4. Roll gem slots (count by rarity)
        int gemSlots = gemSlotCount(rarity);
        root.putInt(K_GEM_SLOTS, gemSlots);
        root.put(K_GEM_LIST, new ListTag()); // empty — gems added later by player

        // 5. Write mmorpg_gear JSON so M&S recognizes the item for gem socketing
        if (TinkRarityLoot.MINE_AND_SLASH_LOADED) {
            writeMmorpgGear(root, rarity, gemSlots, affixes);
        }

        // 6. Mark applied so this doesn't run twice
        root.putByte(K_RPG_APPLIED, (byte) 1);

        TinkRarityLoot.LOGGER.info(
                "[TRL] RPG applied (native TRL): rarity={} level={} req_lvl={} str={} dex={} int={} affixes={} gems={}",
                rarity.displayName, mobLevel,
                reqs.level(), reqs.str(), reqs.dex(), reqs.intel(),
                affixes.size(), gemSlots);
    }

    private static void storeFamily(CompoundTag root, WeaponFamily family) {
        // Store family so MnSBridgeFinalizer can retrieve it
        root.putString("trl_weapon_family", family.name());
    }

    /** Gem slot count by rarity (per M_AND_S_COMPATIBILITY.md). */
    private static int gemSlotCount(TRLRarity rarity) {
        return switch (rarity) {
            case COMMON, UNCOMMON  -> 0;
            case RARE              -> 1;
            case EPIC              -> 2;
            case UNIQUE            -> 3;
            case LEGENDARY, MYTHIC -> 4;
        };
    }

    /**
     * Write mmorpg_gear JSON tag so Mine and Slash recognizes the item and
     * enables gem socketing. M&S reads this JSON to determine socket count,
     * gear rarity, and affix data.
     */
    private static void writeMmorpgGear(CompoundTag root, TRLRarity rarity,
                                         int gemSlots, List<TRLAffix> affixes) {
        String masRarity = switch (rarity) {
            case COMMON    -> "normal";
            case UNCOMMON  -> "magic";
            case RARE      -> "rare";
            case EPIC      -> "epic";
            case UNIQUE    -> "unique";
            case LEGENDARY, MYTHIC -> "legendary";
        };

        // Build prefixes/suffixes arrays
        StringBuilder preBuf = new StringBuilder("[");
        StringBuilder sufBuf = new StringBuilder("[");
        boolean firstPre = true, firstSuf = true;
        for (TRLAffix affix : affixes) {
            String entry = String.format("{\"id\":\"%s\",\"p\":%d}",
                    sanitizeJsonString(affix.type()), (int)(affix.value() * 10));
            if (affix.isPrefix()) {
                if (!firstPre) preBuf.append(",");
                preBuf.append(entry);
                firstPre = false;
            } else {
                if (!firstSuf) sufBuf.append(",");
                sufBuf.append(entry);
                firstSuf = false;
            }
        }
        preBuf.append("]");
        sufBuf.append("]");

        // Build sockets array (empty gems)
        StringBuilder socketsBuf = new StringBuilder("[");
        for (int i = 0; i < gemSlots; i++) {
            if (i > 0) socketsBuf.append(",");
            socketsBuf.append("{\"gem\":\"\"}");
        }
        socketsBuf.append("]");

        // Potential system (limits modification count)
        int potential = switch (rarity) {
            case COMMON    -> 3;
            case UNCOMMON  -> 4;
            case RARE      -> 6;
            case EPIC      -> 8;
            case UNIQUE    -> 10;
            case LEGENDARY -> 12;
            case MYTHIC    -> 15;
        };

        String json = String.format(
                "{\"rarity\":\"%s\",\"affixes\":{\"pre\":%s,\"suf\":%s},"
              + "\"sockets\":%s,\"potential\":%d,\"trl_managed\":true}",
                masRarity, preBuf, sufBuf, socketsBuf, potential);

        root.putString("mmorpg_gear", json);
    }

    /** Sanitize a string for JSON embedding (escape quotes and backslashes). */
    private static String sanitizeJsonString(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
