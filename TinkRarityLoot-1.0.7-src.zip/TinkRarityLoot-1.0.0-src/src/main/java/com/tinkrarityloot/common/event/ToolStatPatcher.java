package com.tinkrarityloot.common.event;

import com.tinkrarityloot.TinkRarityLoot;
import com.tinkrarityloot.common.rpg.TRLAffix;
import com.tinkrarityloot.common.rpg.TRLRequirements;
import com.tinkrarityloot.compat.tinkers.TinkersStatInjector;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.ItemAttributeModifierEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingEquipmentChangeEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerContainerEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.UUID;

/**
 * Single authority for writing TRL bonuses into tic_stats.
 *
 * ── Why server-only with forced sync ─────────────────────────────────────
 *
 * Running patch() on both client and server causes oscillation: TCon rebuilds
 * tic_stats independently on each side, and the server's item sync packets
 * overwrite the client's patched copy. Running on both sides creates a
 * race between the two copies.
 *
 * The correct approach: patch ONLY on the server, then immediately call
 * broadcastChanges() to push the patched NBT to the client. The client
 * never patches — it always receives the authoritative patched copy from
 * the server. This eliminates oscillation entirely.
 *
 * For the station UI display (slot 0), we patch server-side in the tick
 * and immediately broadcast so the client sees updated stat bars without
 * needing a menu reopen.
 *
 * ── Idempotency ──────────────────────────────────────────────────────────
 *
 * Full fingerprint of all six tic_stats values. patch() only writes when
 * the fingerprint differs from stored trl_stat_fp.
 */
public class ToolStatPatcher {

    // Stable UUID for TRL max-health attribute modifier (prevents stacking)
    private static final UUID TRL_MAX_HP_UUID =
            UUID.fromString("7f1d2e3a-4b5c-6d7e-8f9a-0b1c2d3e4f5a");

    private static final String K_BASE_DUR   = "trl_base_dur";
    private static final String K_BASE_DMG   = "trl_base_dmg";
    private static final String K_BASE_ASPD  = "trl_base_aspd";
    private static final String K_BASE_VEL   = "trl_base_vel";
    private static final String K_BASE_DRAW  = "trl_base_draw";
    private static final String K_BASE_ACC   = "trl_base_acc";
    private static final String K_FINAL_DUR  = "trl_final_dur";
    private static final String K_FINAL_DMG  = "trl_final_dmg";
    private static final String K_FINAL_ASPD = "trl_final_aspd";
    private static final String K_FINAL_VEL  = "trl_final_vel";
    private static final String K_FINAL_DRAW = "trl_final_draw";
    private static final String K_FINAL_ACC  = "trl_final_acc";
    private static final String K_STAT_FP    = "trl_stat_fp";

    private static final String TC_DUR  = "tconstruct:durability";
    private static final String TC_DMG  = "tconstruct:attack_damage";
    private static final String TC_ASPD = "tconstruct:attack_speed";
    private static final String TC_VEL  = "tconstruct:velocity";
    private static final String TC_DRAW = "tconstruct:draw_speed";
    private static final String TC_ACC  = "tconstruct:accuracy";

    // ── Server-only tick (cursor + station output + inventory scan) ────────────────────────────

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        // Patch on both sides to ensure client display is correct, but only broadcast changes on server
        // The fingerprint prevents oscillation since both sides use identical logic
        Player player = event.player;
        boolean isServer = !player.level().isClientSide();

        AbstractContainerMenu menu = player.containerMenu;
        boolean changed = false;

        // Cursor item — fixes stat reset when dragging
        if (menu != null) {
            ItemStack carried = menu.getCarried();
            if (!carried.isEmpty()) changed |= patch(carried, isServer);

            // Station output slot 0 — fixes stat bars in the TCon UI
            if (menu.slots.size() > 0) {
                ItemStack output = menu.slots.get(0).getItem();
                if (!output.isEmpty()
                        && output.hasTag()
                        && output.getTag().contains("tic_stats")
                        && output.getTag().getByte(TinkersStatInjector.K_APPLIED) == 1) {
                    changed |= patch(output, isServer);
                }
            }
            
            // Scan visible menu slots for TRL items (first 54 slots to avoid performance issues)
            // This catches items in open containers and inventory GUI
            int slotsToScan = Math.min(menu.slots.size(), 54);
            for (int i = 0; i < slotsToScan; i++) {
                ItemStack stack = menu.slots.get(i).getItem();
                if (!stack.isEmpty()
                        && stack.hasTag()
                        && stack.getTag().contains("tic_stats")
                        && stack.getTag().getByte(TinkersStatInjector.K_APPLIED) == 1) {
                    changed |= patch(stack, isServer);
                }
            }
        }

        // Equipped items — check every tick for immediate response
        ItemStack mainHand = player.getMainHandItem();
        ItemStack offHand = player.getOffhandItem();
        if (!mainHand.isEmpty()
                && mainHand.hasTag()
                && mainHand.getTag().contains("tic_stats")
                && mainHand.getTag().getByte(TinkersStatInjector.K_APPLIED) == 1) {
            changed |= patch(mainHand, isServer);
        }
        if (!offHand.isEmpty()
                && offHand.hasTag()
                && offHand.getTag().contains("tic_stats")
                && offHand.getTag().getByte(TinkersStatInjector.K_APPLIED) == 1) {
            changed |= patch(offHand, isServer);
        }

        // Periodic inventory scan — fixes stats on stored items
        // Scan every tick for maximum responsiveness
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (!stack.isEmpty()
                    && stack.hasTag()
                    && stack.getTag().contains("tic_stats")
                    && stack.getTag().getByte(TinkersStatInjector.K_APPLIED) == 1) {
                changed |= patch(stack, isServer);
            }
        }

        // Only broadcast on server when we actually changed something — avoids flooding
        if (changed && isServer && player instanceof ServerPlayer sp) {
            if (menu != null) menu.broadcastChanges();
            else sp.inventoryMenu.broadcastChanges();
        }

        // ── Requirement enforcement (server-only, every 20 ticks = 1 second) ──
        if (isServer && player.tickCount % 20 == 0) {
            enforceRequirements(player);
        }
    }

    // ── Server-only inventory coverage ───────────────────────────────────────

    @SubscribeEvent
    public void onEquipmentChange(LivingEquipmentChangeEvent event) {
        EquipmentSlot slot = event.getSlot();
        if (slot != EquipmentSlot.MAINHAND && slot != EquipmentSlot.OFFHAND) return;
        LivingEntity entity = event.getEntity();
        // Patch on both sides — client patches for display, server patches for combat
        // Both use identical fingerprint logic so they never compound
        boolean isServer = !entity.level().isClientSide();
        boolean changedTo = patch(event.getTo(), isServer);
        boolean changedFrom = patch(event.getFrom(), isServer);
        if ((changedTo || changedFrom) && isServer && entity instanceof ServerPlayer sp)
            sp.inventoryMenu.broadcastChanges();
    }

    @SubscribeEvent
    public void onItemPickup(PlayerEvent.ItemPickupEvent event) {
        if (event.getEntity().level().isClientSide()) return;
        ItemStack stack = event.getStack();
        if (stack.hasTag() && stack.getTag().getByte(TinkersStatInjector.K_APPLIED) == 1) {
            if (patch(stack, true) && event.getEntity() instanceof ServerPlayer sp)
                sp.inventoryMenu.broadcastChanges();
        }
    }

    @SubscribeEvent
    public void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        Player player = event.getEntity();
        if (player.level().isClientSide()) return;
        patchInventory(player);
    }

    @SubscribeEvent
    public void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        Player player = event.getEntity();
        if (player.level().isClientSide()) return;
        patchInventory(player);
    }

    @SubscribeEvent
    public void onContainerOpen(PlayerContainerEvent.Open event) {
        Player player = event.getEntity();
        if (player.level().isClientSide()) return;
        AbstractContainerMenu menu = event.getContainer();
        
        // Scan container slots for TRL items and patch them
        // Limit to first 54 slots to avoid performance issues with large containers
        int slotsToScan = Math.min(menu.slots.size(), 54);
        boolean changed = false;
        for (int i = 0; i < slotsToScan; i++) {
            ItemStack stack = menu.slots.get(i).getItem();
            if (!stack.isEmpty()
                    && stack.hasTag()
                    && stack.getTag().contains("tic_stats")
                    && stack.getTag().getByte(TinkersStatInjector.K_APPLIED) == 1) {
                changed |= patch(stack, true);
            }
        }
        
        // Also scan player's inventory when opening containers
        if (player instanceof ServerPlayer sp) {
            for (int i = 0; i < sp.getInventory().getContainerSize(); i++) {
                ItemStack stack = sp.getInventory().getItem(i);
                if (!stack.isEmpty()
                        && stack.hasTag()
                        && stack.getTag().contains("tic_stats")
                        && stack.getTag().getByte(TinkersStatInjector.K_APPLIED) == 1) {
                    changed |= patch(stack, true);
                }
            }
        }
        
        if (changed && player instanceof ServerPlayer sp) {
            menu.broadcastChanges();
            sp.inventoryMenu.broadcastChanges();
        }
    }

    @SubscribeEvent
    public void onContainerClose(PlayerContainerEvent.Close event) {
        Player player = event.getEntity();
        if (player.level().isClientSide()) return;
        
        // Scan player's inventory when closing containers to ensure stats persist
        if (player instanceof ServerPlayer sp) {
            boolean changed = false;
            for (int i = 0; i < sp.getInventory().getContainerSize(); i++) {
                ItemStack stack = sp.getInventory().getItem(i);
                if (!stack.isEmpty()
                        && stack.hasTag()
                        && stack.getTag().contains("tic_stats")
                        && stack.getTag().getByte(TinkersStatInjector.K_APPLIED) == 1) {
                    changed |= patch(stack, true);
                }
            }
            
            if (changed) {
                sp.inventoryMenu.broadcastChanges();
            }
        }
    }

    // ── Requirement enforcement ──────────────────────────────────────────────────

    /**
     * Checks mainhand and offhand for TRL level/stat requirements.
     * If the player doesn't meet the requirements, the item is dropped at their feet
     * and they receive a chat message explaining which requirement was not met.
     *
     * Level: Uses M&S player level if available, otherwise vanilla XP level.
     * Stats (STR/DEX/INT): Only enforced when M&S is loaded (since stats come from M&S).
     */
    private static void enforceRequirements(Player player) {
        if (player.isCreative() || player.isSpectator()) return;

        checkAndDropIfUnmet(player, player.getMainHandItem(), EquipmentSlot.MAINHAND);
        checkAndDropIfUnmet(player, player.getOffhandItem(), EquipmentSlot.OFFHAND);
    }

    private static boolean enforcementLogged = false;

    private static void checkAndDropIfUnmet(Player player, ItemStack stack, EquipmentSlot slot) {
        if (stack.isEmpty() || !stack.hasTag()) return;
        CompoundTag root = stack.getTag();
        if (!root.contains(TRLRequirements.K_LEVEL)) return;

        int reqLevel = root.getInt(TRLRequirements.K_LEVEL);
        if (reqLevel <= 1) return; // No effective requirement

        int playerLevel = getPlayerLevel(player);

        // Log once for debugging M&S integration
        if (!enforcementLogged) {
            enforcementLogged = true;
            TinkRarityLoot.LOGGER.info("[TRL] Requirement check: playerLevel={} reqLevel={} (M&S loaded={})",
                    playerLevel, reqLevel, TinkRarityLoot.MINE_AND_SLASH_LOADED);
        }

        if (playerLevel < reqLevel) {
            dropAndNotify(player, stack, slot,
                    "You need Level " + reqLevel + " to wield this weapon! (You are Level " + playerLevel + ")");
            return;
        }

        // Stat requirements — only enforce when M&S is loaded and we can read stats
        if (!TinkRarityLoot.MINE_AND_SLASH_LOADED) return;
        int[] playerStats = getPlayerStats(player);
        boolean statsAvailable = playerStats[0] > 0 || playerStats[1] > 0 || playerStats[2] > 0;
        if (!statsAvailable) return; // Can't enforce if we can't read stats

        int reqStr  = root.getInt(TRLRequirements.K_STR);
        int reqDex  = root.getInt(TRLRequirements.K_DEX);
        int reqInt  = root.getInt(TRLRequirements.K_INT);

        if (reqStr > 0 && playerStats[0] < reqStr) {
            dropAndNotify(player, stack, slot,
                    "You need STR " + reqStr + " to wield this weapon! (You have STR " + playerStats[0] + ")");
            return;
        }
        if (reqDex > 0 && playerStats[1] < reqDex) {
            dropAndNotify(player, stack, slot,
                    "You need DEX " + reqDex + " to wield this weapon! (You have DEX " + playerStats[1] + ")");
            return;
        }
        if (reqInt > 0 && playerStats[2] < reqInt) {
            dropAndNotify(player, stack, slot,
                    "You need INT " + reqInt + " to wield this weapon! (You have INT " + playerStats[2] + ")");
        }
    }

    private static void dropAndNotify(Player player, ItemStack stack, EquipmentSlot slot, String reason) {
        // Drop the item at the player's feet
        ItemEntity dropped = player.drop(stack.copy(), false);
        if (dropped != null) {
            dropped.setNoPickUpDelay(); // Allow immediate re-pick once requirements are met
            // Set a brief pickup delay to prevent instant re-equip loops
            dropped.setPickUpDelay(40); // 2 seconds
        }

        // Clear the slot
        if (slot == EquipmentSlot.MAINHAND) {
            player.getInventory().setItem(player.getInventory().selected, ItemStack.EMPTY);
        } else if (slot == EquipmentSlot.OFFHAND) {
            player.getInventory().offhand.set(0, ItemStack.EMPTY);
        }

        // Notify the player
        player.displayClientMessage(
                Component.literal("[TRL] ").withStyle(ChatFormatting.RED)
                        .append(Component.literal(reason).withStyle(ChatFormatting.YELLOW)),
                true); // actionbar message

        if (player instanceof ServerPlayer sp) {
            sp.inventoryMenu.broadcastChanges();
        }
    }

    /**
     * Returns the player's level for requirement checks.
     *
     * Priority chain:
     * 1. MnSBridge (reflection into M&S Load class / getPersistentData)
     * 2. MineAndSlashCompat (capability-based IEntityStats.getLevel)
     * 3. Vanilla XP level (final fallback so enforcement always works)
     */
    private static boolean levelFallbackLogged = false;

    private static int getPlayerLevel(Player player) {
        if (TinkRarityLoot.MINE_AND_SLASH_LOADED) {
            // Try MnSBridge first (reflection + getPersistentData)
            int level = com.tinkrarityloot.compat.mineandslash.MnSBridge.getPlayerLevel(player);
            if (level > 0) return level;

            // Try MineAndSlashCompat capability-based approach (works for players too)
            Integer capLevel = com.tinkrarityloot.compat.mineandslash.MineAndSlashCompat.getMobLevel(player);
            if (capLevel != null && capLevel > 0) return capLevel;
        }

        // Fallback: vanilla XP level (ensures enforcement always works)
        int xpLevel = player.experienceLevel;
        if (!levelFallbackLogged && TinkRarityLoot.MINE_AND_SLASH_LOADED) {
            levelFallbackLogged = true;
            TinkRarityLoot.LOGGER.warn("[TRL] M&S bridges cannot read player level — "
                    + "using vanilla XP level ({}) for requirement checks. "
                    + "If M&S levels differ, report this to TRL developers.",
                    xpLevel);
        }
        return Math.max(1, xpLevel);
    }

    /**
     * Returns [STR, DEX, INT] from M&S player data.
     * Returns [0,0,0] if M&S is not loaded or stats cannot be read.
     */
    private static int[] getPlayerStats(Player player) {
        return com.tinkrarityloot.compat.mineandslash.MnSBridge.getPlayerStats(player);
    }

    // ── Combat damage injection ─────────────────────────────────────────────────

    /**
     * Log pre-armor damage for diagnostics. Actual injection happens in
     * onLivingDamage() to survive M&S overrides.
     */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onLivingHurt(LivingHurtEvent event) {
        if (event.getEntity().level().isClientSide()) return;
        if (event.getSource() == null) return;
        Entity directEntity = event.getSource().getDirectEntity();
        if (directEntity instanceof Player || directEntity instanceof Projectile) {
            TinkRarityLoot.LOGGER.debug("[TRL] LivingHurtEvent (pre-armor): {} amount={}",
                    event.getEntity().getName().getString(), f(event.getAmount()));
        }
    }

    /**
     * Tag projectile entities with TRL damage bonus and affix data at launch time.
     * When a player fires/throws a TRL weapon, the bonus and affix NBT are stored
     * on the projectile's persistent data so they can be read in onLivingDamage()
     * when the projectile hits a target.
     */
    @SubscribeEvent
    public void onEntityJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        Entity entity = event.getEntity();
        if (!(entity instanceof Projectile proj)) return;
        Entity owner = proj.getOwner();
        if (!(owner instanceof Player player)) return;

        ItemStack weapon = player.getMainHandItem();
        if (weapon.isEmpty() || !weapon.hasTag()) return;
        CompoundTag root = weapon.getTag();
        if (root.getByte(TinkersStatInjector.K_APPLIED) != 1) return;

        CompoundTag projData = entity.getPersistentData();
        float bonusDmg = root.getFloat(TinkersStatInjector.K_B_DMG);
        if (bonusDmg > 0f) {
            projData.putFloat("trl_dmg_bonus", bonusDmg);
        }
        // Copy affix list so projectiles can apply crit/life-steal on hit
        if (root.contains(TRLAffix.K_LIST)) {
            projData.put("trl_affixes", root.getList(TRLAffix.K_LIST, Tag.TAG_COMPOUND).copy());
        }
        if (bonusDmg > 0f) {
            TinkRarityLoot.LOGGER.debug("[TRL] Tagged projectile {} with bonus DMG {}",
                    entity.getType().toShortString(), f(bonusDmg));
        }
    }

    /**
     * Inject TRL damage bonus and apply combat affix effects.
     *
     * Handles: base damage bonus, PHYS_DMG_PCT, elemental flat damage,
     * CRIT_CHANCE + CRIT_DMG, and LIFE_STEAL.
     */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onLivingDamage(LivingDamageEvent event) {
        if (event.getEntity().level().isClientSide()) return;
        if (event.getSource() == null) return;

        Entity sourceEntity = event.getSource().getEntity();
        Entity directEntity = event.getSource().getDirectEntity();

        float bonusDmg = 0f;
        ListTag affixList = null;
        Player attackingPlayer = null;
        String debugSource = "none";

        // Case 1: Direct melee attack (player is the direct entity)
        if (directEntity instanceof Player player) {
            ItemStack weapon = player.getMainHandItem();
            if (!weapon.isEmpty() && weapon.hasTag()) {
                CompoundTag root = weapon.getTag();
                if (root.getByte(TinkersStatInjector.K_APPLIED) == 1) {
                    bonusDmg = root.getFloat(TinkersStatInjector.K_B_DMG);
                    if (root.contains(TRLAffix.K_LIST))
                        affixList = root.getList(TRLAffix.K_LIST, Tag.TAG_COMPOUND);
                    attackingPlayer = player;
                    debugSource = "melee";
                }
            }
        }
        // Case 2: Projectile attack (arrow, thrown spear — projectile is direct entity)
        else if (directEntity instanceof Projectile && sourceEntity instanceof Player player) {
            CompoundTag projData = directEntity.getPersistentData();
            if (projData.contains("trl_dmg_bonus")) {
                bonusDmg = projData.getFloat("trl_dmg_bonus");
                if (projData.contains("trl_affixes"))
                    affixList = projData.getList("trl_affixes", Tag.TAG_COMPOUND);
                attackingPlayer = player;
                debugSource = "projectile";
            }
        }

        if (bonusDmg <= 0f && affixList == null) return;

        // ── Parse affixes for combat effects ──
        float physDmgPct = 0f;       // % physical damage increase
        float flatElemDmg = 0f;      // flat elemental damage (fire/ice/lightning/poison)
        float critChance = 0f;       // crit chance % (0-100)
        float critDmgMult = 0f;      // crit damage multiplier % (e.g. 35 = +35%)
        float lifeStealPct = 0f;     // life steal %

        if (affixList != null) {
            for (int i = 0; i < affixList.size(); i++) {
                TRLAffix affix = TRLAffix.fromNbt(affixList.getCompound(i));
                switch (affix.type()) {
                    case TRLAffix.PHYS_DMG_PCT  -> physDmgPct  += affix.value();
                    case TRLAffix.FIRE_DMG      -> flatElemDmg += affix.value();
                    case TRLAffix.ICE_DMG       -> flatElemDmg += affix.value();
                    case TRLAffix.LIGHTNING_DMG -> flatElemDmg += affix.value();
                    case TRLAffix.POISON_DMG    -> flatElemDmg += affix.value();
                    case TRLAffix.CRIT_CHANCE   -> critChance  += affix.value();
                    case TRLAffix.CRIT_DMG      -> critDmgMult += affix.value();
                    case TRLAffix.LIFE_STEAL    -> lifeStealPct += affix.value();
                }
            }
        }

        // ── Calculate total damage ──
        float totalDmg = bonusDmg;

        // Physical damage %: scale the base bonus
        if (physDmgPct > 0f) {
            totalDmg *= (1f + physDmgPct / 100f);
        }

        // Add flat elemental damage
        totalDmg += flatElemDmg;

        // Crit roll
        boolean isCrit = false;
        if (critChance > 0f) {
            float roll = event.getEntity().getRandom().nextFloat() * 100f;
            if (roll < critChance) {
                isCrit = true;
                float critMult = 1.5f + (critDmgMult / 100f); // base 1.5x + bonus
                totalDmg *= critMult;
            }
        }

        if (totalDmg > 0f) {
            LivingEntity target = event.getEntity();
            if (TinkRarityLoot.MINE_AND_SLASH_LOADED) {
                // M&S uses Mixins to bypass Forge event amounts — apply damage
                // directly to entity health so it cannot be overridden.
                float hp = target.getHealth();
                float newHp = Math.max(0f, hp - totalDmg);
                target.setHealth(newHp);
                if (newHp <= 0f) {
                    target.die(event.getSource());
                }
                TinkRarityLoot.LOGGER.info("[TRL] DMG inject (direct HP): hp {} -> {} (-{}{}) [{}] target={}",
                        f(hp), f(newHp), f(totalDmg), isCrit ? " CRIT" : "", debugSource,
                        target.getName().getString());
            } else {
                float before = event.getAmount();
                event.setAmount(before + totalDmg);
                TinkRarityLoot.LOGGER.info("[TRL] DMG inject (event): {} -> {} (+{}{}) [{}] target={}",
                        f(before), f(before + totalDmg), f(totalDmg), isCrit ? " CRIT" : "", debugSource,
                        target.getName().getString());
            }

            // Life steal: heal attacking player
            if (lifeStealPct > 0f && attackingPlayer != null) {
                float healAmount = totalDmg * (lifeStealPct / 100f);
                attackingPlayer.heal(healAmount);
                TinkRarityLoot.LOGGER.debug("[TRL] Life steal: healed {} for {}",
                        attackingPlayer.getName().getString(), f(healAmount));
            }
        }
    }

    // ── Player attribute modifiers from TRL affixes ──────────────────────────────

    /**
     * Attribute modifiers for affix-based player stats (MAX_HP_PCT, etc.).
     * Note: DMG is injected via LivingHurtEvent; ASPD via tic_stats.
     * This handler only covers player-affecting affixes like MAX_HP_PCT.
     */
    @SubscribeEvent
    public void onItemAttribute(ItemAttributeModifierEvent event) {
        if (event.getSlotType() != EquipmentSlot.MAINHAND) return;
        ItemStack stack = event.getItemStack();
        if (!stack.hasTag()) return;
        CompoundTag root = stack.getTag();
        if (root.getByte(TinkersStatInjector.K_APPLIED) != 1) return;
        if (!root.contains(TRLAffix.K_LIST)) return;

        ListTag affixList = root.getList(TRLAffix.K_LIST, Tag.TAG_COMPOUND);
        for (int i = 0; i < affixList.size(); i++) {
            TRLAffix affix = TRLAffix.fromNbt(affixList.getCompound(i));
            if (TRLAffix.MAX_HP_PCT.equals(affix.type())) {
                event.addModifier(
                        Attributes.MAX_HEALTH,
                        new AttributeModifier(
                                TRL_MAX_HP_UUID,
                                "TRL Max HP Bonus",
                                affix.value() / 100.0,
                                AttributeModifier.Operation.MULTIPLY_BASE
                        )
                );
            }
        }
    }
    // ── Core ─────────────────────────────────────────────────────────────────

    public static int patchInventory(Player player) {
        int patched = 0;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            if (patch(player.getInventory().getItem(i), !player.level().isClientSide())) patched++;
        }
        if (patched > 0)
            TinkRarityLoot.LOGGER.debug("[TRL] patchInventory: {} tool(s) for {}",
                    patched, player.getName().getString());
        return patched;
    }

    /**
     * Idempotent patch. Returns true if tic_stats was written.
     * Uses full fingerprint to detect TCon rebuilds.
     */
    public static boolean patch(ItemStack stack) {
        return patch(stack, true);
    }

    /**
     * Idempotent patch. Returns true if tic_stats was written.
     * Uses full fingerprint to detect TCon rebuilds.
     */
    public static boolean patch(ItemStack stack, boolean isServer) {
        if (stack.isEmpty() || !stack.hasTag()) return false;
        CompoundTag root = stack.getTag();
        if (root.getByte(TinkersStatInjector.K_APPLIED) != 1) return false;
        if (!root.contains("tic_stats", Tag.TAG_COMPOUND)) return false;

        CompoundTag stats = root.getCompound("tic_stats");
        if (!stats.contains(TC_DUR)) return false;

        float bonusDur  = root.getFloat(TinkersStatInjector.K_B_DUR);
        float bonusDmg  = root.getFloat(TinkersStatInjector.K_B_DMG);
        float bonusVel  = root.getFloat(TinkersStatInjector.K_B_VEL);
        float bonusDraw = root.getFloat(TinkersStatInjector.K_B_DRAW);
        float bonusAcc  = root.getFloat(TinkersStatInjector.K_B_ACC);
        // Attack speed bonus only injected at EPIC+ (rarity_idx >= 3).
        // The value is stored on all parts for tooltip display, but the tool
        // stat only gains it once the assembled rarity reaches EPIC tier.
        int rarityIdx = root.getInt("trl_rarity_idx");
        float bonusAspd = (rarityIdx >= 3) ? root.getFloat(TinkersStatInjector.K_B_ATKSPD) : 0f;

        int currentFP = fingerprint(stats);
        if (root.contains(K_STAT_FP) && root.getInt(K_STAT_FP) == currentFP) {
            return false; // Already patched
        }

        float baseDur  = stats.getFloat(TC_DUR);
        float baseDmg  = stats.contains(TC_DMG)  ? stats.getFloat(TC_DMG)  : 0f;
        float baseAspd = stats.contains(TC_ASPD) ? stats.getFloat(TC_ASPD) : 0f;
        float baseVel  = stats.contains(TC_VEL)  ? stats.getFloat(TC_VEL)  : 0f;
        float baseDraw = stats.contains(TC_DRAW) ? stats.getFloat(TC_DRAW) : 0f;
        float baseAcc  = stats.contains(TC_ACC)  ? stats.getFloat(TC_ACC)  : 0f;

        float finalDur  = baseDur  + bonusDur;
        float finalDmg  = baseDmg  + bonusDmg;
        float finalAspd = baseAspd + bonusAspd;
        float finalVel  = baseVel  + bonusVel;
        float finalDraw = baseDraw + bonusDraw;
        float finalAcc  = baseAcc  + bonusAcc;

        stats.putFloat(TC_DUR, finalDur);
        // DMG is NOT written to tic_stats — it is applied exclusively via
        // LivingHurtEvent to avoid double-counting with TCon's ATTACK_DAMAGE
        // attribute (which reads from tic_stats).
        if (bonusAspd != 0f) stats.putFloat(TC_ASPD, finalAspd);
        if (bonusVel  != 0f) stats.putFloat(TC_VEL,  finalVel);
        if (bonusDraw != 0f) stats.putFloat(TC_DRAW, finalDraw);
        if (bonusAcc  != 0f) stats.putFloat(TC_ACC,  finalAcc);

        root.putFloat(K_BASE_DUR,  baseDur);   root.putFloat(K_FINAL_DUR,  finalDur);
        root.putFloat(K_BASE_DMG,  baseDmg);   root.putFloat(K_FINAL_DMG,  finalDmg);
        root.putFloat(K_BASE_ASPD, baseAspd);  root.putFloat(K_FINAL_ASPD, finalAspd);
        root.putFloat(K_BASE_VEL,  baseVel);   root.putFloat(K_FINAL_VEL,  finalVel);
        root.putFloat(K_BASE_DRAW, baseDraw);  root.putFloat(K_FINAL_DRAW, finalDraw);
        root.putFloat(K_BASE_ACC,  baseAcc);   root.putFloat(K_FINAL_ACC,  finalAcc);
        root.putInt(K_STAT_FP, fingerprint(stats));

        // Only log on server (Render thread = client side)
        if (isServer) {
            TinkRarityLoot.LOGGER.info("[TRL] Patched: dur {}+{}={} dmg {}+{}={} aspd {}+{}={}",
                    (int)baseDur, (int)bonusDur, (int)finalDur,
                    f(baseDmg), f(bonusDmg), f(finalDmg),
                    f(baseAspd), f(bonusAspd), f(finalAspd));
        }
        return true;
    }

    private static int fingerprint(CompoundTag stats) {
        int h = Float.floatToIntBits(stats.getFloat(TC_DUR));
        h = h * 31 + Float.floatToIntBits(stats.getFloat(TC_DMG));
        h = h * 31 + Float.floatToIntBits(stats.getFloat(TC_ASPD));
        h = h * 31 + Float.floatToIntBits(stats.getFloat(TC_VEL));
        h = h * 31 + Float.floatToIntBits(stats.getFloat(TC_DRAW));
        h = h * 31 + Float.floatToIntBits(stats.getFloat(TC_ACC));
        return h;
    }

    private static String f(float v) { return String.format("%.2f", v); }
}
