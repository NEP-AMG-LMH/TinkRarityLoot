package com.tinkrarityloot.common.event;

import com.tinkrarityloot.client.tooltip.TooltipRenderer;
import com.tinkrarityloot.compat.tinkers.TinkersStatInjector;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import slimeknights.tconstruct.library.tools.part.IToolPart;

import java.util.List;

/**
 * Event handler that routes tooltip requests to {@link TooltipRenderer}.
 *
 * Priority is HIGHEST so TRL's lines always appear before anything Mine and
 * Slash or Apotheosis inject into the same event.
 *
 * TRL is the sole visual authority:
 *   - We read only our own NBT / capability.
 *   - We never consult M&S or Apotheosis APIs here.
 *   - M&S and Apotheosis add their own lines at lower priority afterward.
 *
 * For TRL-assembled tools, vanilla's "When in Main Hand:" attribute lines for
 * Attack Damage and Attack Speed are removed because TRL shows these stats
 * in a richer Base + Bonus = Final format. This prevents confusing duplicates
 * (especially since TRL damage is injected via LivingHurtEvent, not tic_stats,
 * so vanilla's attribute line would show a lower value).
 */
@OnlyIn(Dist.CLIENT)
public class TooltipHandler {

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onItemTooltip(ItemTooltipEvent event) {
        ItemStack stack = event.getItemStack();

        if (stack.getItem() instanceof IToolPart) {
            TooltipRenderer.appendPartLines(stack, event.getToolTip());
        } else {
            // Assembled tools (TCon tool items that are not IToolPart)
            TooltipRenderer.appendToolLines(stack, event.getToolTip(), event.getEntity());

            // Remove vanilla's duplicate damage/speed attribute lines for TRL tools
            if (stack.hasTag() && stack.getTag().getByte(TinkersStatInjector.K_APPLIED) == 1) {
                cleanVanillaAttributeLines(event.getToolTip());
            }
        }
    }

    /**
     * Remove vanilla's "When in Main Hand:" attribute section entries for
     * Attack Damage and Attack Speed. TRL shows these in a richer format.
     * If removing those lines empties the section, the header is removed too.
     */
    private static void cleanVanillaAttributeLines(List<Component> lines) {
        int headerIdx = -1;
        int sectionStart = -1;
        int sectionEnd = -1;
        int removedInSection = 0;
        int totalInSection = 0;

        // Find the "When in Main Hand:" section and its extent
        for (int i = 0; i < lines.size(); i++) {
            String text = lines.get(i).getString().trim();

            if (text.contains("When in Main Hand") || text.contains("when_used.mainhand")) {
                headerIdx = i;
                sectionStart = i + 1;
            } else if (headerIdx >= 0 && sectionStart >= 0 && sectionEnd < 0) {
                // We're inside the section — check if this line is part of it
                if (text.isEmpty()) {
                    sectionEnd = i;
                    break;
                }
                // Check for another "When in ..." header (e.g., "When in Off Hand:")
                if (text.startsWith("When in ") || text.contains("when_used.")) {
                    sectionEnd = i;
                    break;
                }
                totalInSection++;
            }
        }

        // If section runs to end of list
        if (headerIdx >= 0 && sectionStart >= 0 && sectionEnd < 0) {
            sectionEnd = lines.size();
        }

        if (headerIdx < 0 || sectionStart >= sectionEnd) return;

        // Remove Attack Damage and Attack Speed lines (iterate backwards)
        for (int i = sectionEnd - 1; i >= sectionStart; i--) {
            String text = lines.get(i).getString();
            if (text.contains("Attack Damage") || text.contains("Attack Speed")
                    || text.contains("attack_damage") || text.contains("attack_speed")) {
                lines.remove(i);
                removedInSection++;
            }
        }

        // If we removed ALL lines in the section, remove the header too
        // Also remove the blank line before the header if present
        if (removedInSection > 0 && removedInSection >= totalInSection) {
            // Find the header again (index may have shifted)
            for (int i = 0; i < lines.size(); i++) {
                String text = lines.get(i).getString().trim();
                if (text.contains("When in Main Hand") || text.contains("when_used.mainhand")) {
                    lines.remove(i);
                    // Remove blank line before header if present
                    if (i > 0 && lines.get(i - 1).getString().trim().isEmpty()) {
                        lines.remove(i - 1);
                    }
                    break;
                }
            }
        }
    }
}
